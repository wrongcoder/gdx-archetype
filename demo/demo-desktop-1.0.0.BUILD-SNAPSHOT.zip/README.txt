
Demo Project

Windows:
Double-click on demo.exe to start the game.

Mac OS X 10.7+:
Double-click on Demo Project.app to start the game.

Mac OS X 10.5+:
Double-click on demo.jar to start the game.

Linux:
Double-click on demo.jar to start the game.

If it doesn't work, you may need to install Java: http://java.com/en/download/index.jsp

3D graphics support is required.

