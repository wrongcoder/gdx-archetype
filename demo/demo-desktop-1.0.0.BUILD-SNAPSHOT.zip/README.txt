
Demo Project

Windows: Double-click on demo.exe to start the game.

Other OS: Double-click on demo.jar to start the game.

If it doesn't work, you may need to install Java: http://java.com/en/download/index.jsp

3D graphics support is required.
